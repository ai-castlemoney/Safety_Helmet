def hello_rtdb(event, context):
    """Triggered by a change to a Firebase RTDB reference.
    Args:
         event (dict): Event payload.
         context (google.cloud.functions.Context): Metadata for the event.
    """
    resource_string = context.resource
    # print out the resource string that triggered the function
    print(f"Function triggered by change to: {resource_string}.")
    # now print out the entire event object
    print(str(event))
    # mykey 추가
    # 라이브러리 임포트
# firebase test
    import firebase_admin
    from firebase_admin import credentials
    from firebase_admin import firestore

# Use the application default credentials

    cred = credentials.Certificate('data/mykey.json')
    app = firebase_admin.initialize_app(credential=cred, options=None, name='[DEFAULT]')
    db = firestore.client()

    doc_ref = db.collection(u'permit_to_work').document(u'work_list')

    doc = doc_ref.get()
    if doc.exists:
        print(f'Document data: {doc.to_dict()}')
        doc_dict = doc.to_dict()
        work_dict = doc_dict[event['data']['work_id']] # event context로 부터 작업 id 지정
        facility = work_dict['facility']
        keywords = work_dict['keywords']
        # 공장 정보 읽기
        doc_ref = db.collection(u'facility_db').document(facility)
        doc = doc_ref.get()
        if doc.exists:
            doc_dict = doc.to_dict()
            facility_dict = doc_dict
            facility_attribute = facility_dict['attribute']
            facility_keywords = facility_dict['item']
    else:
        print(u'No such document!')

    doc_ref = db.collection(u'test').document(u'zip_test')
    doc_ref.set({
  u'함수명': 'firebase 함수 테스트',
  u'work_dict': str(work_dict),
  u'facility': facility,
  u'keywords': keywords,
  u'facility_attribute': facility_attribute,
  u'facility_keywords': facility_keywords,
  u'total_keywords': keywords+facility_attribute+facility_keywords,
  u'event': str(event),
  u'context' : str(context)
  })
    firebase_admin.delete_app(app)